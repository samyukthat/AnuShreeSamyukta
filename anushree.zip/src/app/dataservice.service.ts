import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class DataserviceService {
  itemsInCart:Array<any>=[];
  constructor(private http: HttpClient) { }
  getData(){
    return this.http.get('https://api.myjson.com/bins/qhnfp');
  }
  addToCart(item){
    if(this.itemsInCart.indexOf(item) == -1){
      item.quantity = 1;
      this.itemsInCart.push(item)
    }
    else{
      for(let i=0;i<this.itemsInCart.length;i++){
        if(this.itemsInCart[i].id == item.id){
          item.quantity++
          this.itemsInCart[i] = item
        }
      }
    }
  }
  discountPrice(price, discount){
    let disc = (discount)/100;
    let discountAmt = disc*price
    return price - discountAmt
  }

}