import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemsComponent } from './items/items.component';
import { CartPageComponent } from './cart-page/cart-page.component';

export const routes: Routes = [
  { path: 'home', component: ItemsComponent },
  { path: 'cart', component: CartPageComponent},
   { path: '', redirectTo: '/home', pathMatch: 'full'},
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
