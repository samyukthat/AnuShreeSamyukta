import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service'

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {
  bookdetails:any;
  constructor(private dataservice:DataserviceService) { }

  ngOnInit() {
    this.getdata()
  }
  getdata(){
    this.dataservice.getData().subscribe((data)=>{
      this.bookdetails = data;
      console.log(this.bookdetails)
    })
  }
  recalculatePrice(price, discount){
    return this.dataservice.discountPrice(price, discount)
  }
  addItems(book){
    this.dataservice.addToCart(book)
  }
}