import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { ItemsComponent } from './items/items.component';
import { DataserviceService } from './dataservice.service';
import { routing } from './app.route';
import { CartPageComponent } from './cart-page/cart-page.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpClientModule, routing ],
  declarations: [ AppComponent, HelloComponent, ItemsComponent, CartPageComponent ],
  bootstrap:    [ AppComponent ],
  providers: [DataserviceService]
})
export class AppModule { }
