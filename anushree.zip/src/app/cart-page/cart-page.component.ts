import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service'

@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {
  cartData:Array<any>;
  qty:0
  constructor(private dataservice:DataserviceService) { }

  ngOnInit() {
    this.cartData = this.dataservice.itemsInCart
  }
  plusClicked(item){
    item.quantity = item.quantity+1
    //this.cartData = item
  }
  minusClicked(item){
    item.quantity = item.quantity-1
   // this.cartData = item
  }
  getPrice(item){
    return item.price * item.quantity
  }
  getTotal(){
    let qty = 0
    for(let i=0;i<this.cartData.length;i++){
      qty = qty+this.cartData[i].quantity
    }
    return qty
  }
  getSum(){
    let qty = 0
    for(let i=0;i<this.cartData.length;i++){
      qty = qty+(this.cartData[i].price * this.cartData[i].quantity)
    }
    return qty
  }
  getDiscount(){
    let disc = 0;
    for(let i=0;i<this.cartData.length;i++){
       let disc = (this.cartData[i].discount)/100;
       let discountAmt = disc*this.cartData[i].price
       disc = disc+discountAmt
    }
    return disc
  }
}